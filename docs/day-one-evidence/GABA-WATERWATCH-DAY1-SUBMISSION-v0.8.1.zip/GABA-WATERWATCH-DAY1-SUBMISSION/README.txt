GABA WATERWATCH — FNB AOTY DAY-ONE EVIDENCE — 23 OCT 2026

COMPETITION WEBSITE
https://www.lastdicesptyltd.co.za/gabafnbhackaton

ANDROID APK — v0.8.1 Limise Watch cloud demo (debug build, NOT Play Store signed)
https://github.com/SXNGE4444/gaba-waterwatch-fnb-downloads/releases/download/v0.8.1-limise-watch/app-debug.apk

PUBLIC EVIDENCE VIDEO (30 seconds, silent with on-screen stage titles)
https://raw.githubusercontent.com/SXNGE4444/gaba-waterwatch-fnb-downloads/main/docs/day-one-evidence/GABA-WATERWATCH-DAY1-END-TO-END-DEMO.mp4

VIDEO SCOPE
Actual automated Chromium browser recording, run against a LOCAL persistent Node demo. Verifies resident submit, operator inbox, independent simulated reviewer, inspection evidence, closure, resident status. No real municipality contacted.

CLOUD SCOPE
Live public Supabase Edge Function uses isolated Postgres and has passed report creation, private status lookup, duplicate prevention and anonymous operator denial. The FULL cloud staff process requires two verified Supabase Auth staff accounts and fnb_staff_roles assignment. DO NOT CLAIM CLOUD END TO END YET.

TECHNICAL QA
13 local tests passed, browser walkthrough passed with 10 captured screenshots, cloud public acceptance passed 6 stages. The video has no voiceover; use as evidence clip or add narration separately.

NO OFFICIAL WATER FEED, CONFIRMED MUNICIPAL REPORT RECEIPT OR VERIFIED WATER QUALITY DATA.

OCT 24 ANDROID EVIDENCE
Actual v0.8.1 debug APK installed on Pixel 7 Android emulator. Tested online resident submission REP-2E2AB245, offline queue creation and successful sync REP-BC1F801E with local-to-cloud report ID reconciliation. Added 11-android-cloud-activity.png. Staff identities remain pending; recorded day-one video is local synthetic Node demo, NOT a completed protected cloud staff workflow.
