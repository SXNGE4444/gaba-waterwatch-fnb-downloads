GABA WATERWATCH FNB — SIGN-IN REQUIRED — ANDROID v0.9.6
==============================================
This is a real Android APK, not an Android Studio project and not a web preview.
Package identity: za.co.lastdices.gabawaterwatch.fnb
Signature: same debug certificate as the working v0.9.2 app.
Android 7.0+.

INSTALL
1. On your Android phone, visit https://www.lastdicesptyltd.co.za/gabafnbhackaton/download.html
2. Download GABA-WaterWatch-FNB-v0.9.6.apk. Or download ZIP and extract the identical APK.
3. In Files / Downloads, tap the APK. Grant trusted browser/files sideload permission if prompted; leave Play Protect enabled.
4. Tap Install. The app opens directly to Sign in / Create account / Reset password.
5. If new: create account. Supabase sends a verification email opening the Last Dices website. Confirm there, return to APK, sign in.
6. Resident WaterWatch Home, Updates, Report, Activity and Guides require verified sign-in.
7. Reports are tied to the authenticated user and securely stored in the synthetic Supabase demo. Operator and reviewer accounts remain separate.

SMTP EMAIL VERIFICATION — VERIFIED OPERATIONAL
The earlier Resend SMTP 550 sending-domain error is historical and was fixed.
Live Supabase logs show signup HTTP 200 on 2026-10-24 at 11:30:41 UTC and an email verification HTTP 303 redirect at 11:30:49 UTC. The associated account is confirmed and both existing accounts are verified.
All 16 code tests passed and the v0.9.6 APK downloaded through Android Chrome, passed checksum, installed and launched at login.
Still to verify for final judge acceptance: real Android sign-in with a confirmed account, resident report submission tied to that account, logout, and reset-password email receipt. Do not claim these checks passed before exercising them.

GitHub source: https://github.com/SXNGE4444/GABA/tree/03ba497/apps/gaba-waterwatch-fnb
Public download repository: https://github.com/SXNGE4444/gaba-waterwatch-fnb-downloads
