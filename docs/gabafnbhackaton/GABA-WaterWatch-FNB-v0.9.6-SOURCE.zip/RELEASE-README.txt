GABA WATERWATCH FNB — SIGN-IN REQUIRED — ANDROID v0.9.6
==============================================
This is a real Android APK, not an Android Studio project and not a web preview.
Package identity: za.co.lastdices.gabawaterwatch.fnb
Signature: same debug certificate as the working v0.9.2 app.
Android 7.0+.

INSTALL
1. On your Android phone, visit https://www.lastdicesptyltd.co.za/gabafnbhackaton/download.html
2. Download GABA-WaterWatch-FNB-v0.9.6.apk. Or download ZIP and extract the identical APK.
3. In Files / Downloads, tap the APK. Grant trusted browser/files sideload permission if prompted; leave Play Protect enabled.
4. Tap Install. The app opens directly to Sign in / Create account / Reset password.
5. If new: create account. Supabase sends a verification email opening the Last Dices website. Confirm there, return to APK, sign in.
6. Resident WaterWatch Home, Updates, Report, Activity and Guides require verified sign-in.
7. Reports are tied to the authenticated user and securely stored in the synthetic Supabase demo. Operator and reviewer accounts remain separate.

IMPORTANT RELEASE GATE (2026-10-24)
Supabase Auth logs recorded SMTP 550 from Resend: lastdicesptyltd.co.za was not verified as a sending domain.
The APK installation and login UI work, but new-user registration emails CANNOT BE CALLED FULLY VERIFIED until Resend/DNS is corrected and a new user completes email verification. The app deliberately DOES NOT bypass verified login.
Fix at Resend > Domains: check exact DKIM/SPF/MX values for lastdicesptyltd.co.za and verify the domain; DNS is managed by ns1.host-ww.net / ns2.host-ww.net. In Supabase project uskemdfbmuilvirqudml > Auth > SMTP, ensure the From address uses the verified domain.
Test with a real inbox: Register > receive email > confirm on website > sign in on APK > report > Activity > logout > password reset. Only submit synthetic cases; no municipal service is connected.

GitHub source: https://github.com/SXNGE4444/GABA/tree/16f6168/apps/gaba-waterwatch-fnb
Public download repository: https://github.com/SXNGE4444/gaba-waterwatch-fnb-downloads
