// Copy this value to config.js only AFTER the Edge Function passes all smoke tests.
// Project ref/URL are public; never put a service-role key, session token or password here.
window.GABA_API_BASE = 'https://<APPROVED_SUPABASE_PROJECT_REF>.supabase.co/functions/v1/waterwatch-api';
