package za.co.lastdices.gabawaterwatch;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
