'use strict';
/* Public Supabase Auth client only; never include service keys or staff credentials. */
const API='https://uskemdfbmuilvirqudml.supabase.co/auth/v1';
const PUBLIC_KEY='sb_publishable_iZEnOA3f0yvz6M5hnTfOvA_sMYS38Oq';
const REDIRECT='https://www.lastdicesptyltd.co.za/gabafnbhackaton/auth.html';
const $=(s)=>document.querySelector(s);
const accessKey='gaba.resident.access',refreshKey='gaba.resident.refresh';
const storage=localStorage; // Shared website session and Android WebView session are each origin-isolated.
function openNativeApp(){location.replace(window.GABA_NATIVE_LOGIN_FIRST?'community.html':'./?view=community')}
function note(text,error=false){const b=$('#notice');b.style.display='block';b.classList.toggle('error',error);b.textContent=text}
function tab(name){document.querySelectorAll('[data-tab]').forEach(x=>x.setAttribute('aria-selected',String(x.dataset.tab===name)));document.querySelectorAll('.form').forEach(x=>x.classList.toggle('active',x.id===name+'-form'));$('#account-panel').hidden=true}
document.querySelectorAll('[data-tab]').forEach(x=>x.addEventListener('click',()=>{tab(x.dataset.tab);$('#notice').style.display='none'}));
async function call(path,body,method='POST',token){const r=await fetch(API+path,{method,headers:{'Content-Type':'application/json','apikey':PUBLIC_KEY,...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.msg||d.error_description||d.message||d.error||'Authentication request failed ('+r.status+')');return d}
function save(data){if(data.access_token)storage.setItem(accessKey,data.access_token);if(data.refresh_token)storage.setItem(refreshKey,data.refresh_token)}
function clear(){storage.removeItem(accessKey);storage.removeItem(refreshKey)}
async function current(){
  const t=storage.getItem(accessKey);if(!t)return null;
  try{return await call('/user',null,'GET',t)}
  catch{
    const refresh=storage.getItem(refreshKey);if(!refresh){clear();return null}
    try{const renewed=await call('/token?grant_type=refresh_token',{refresh_token:refresh});
      save(renewed);return await call('/user',null,'GET',renewed.access_token)}
    catch{clear();return null}
  }
}
async function showAccount(){const user=await current();if(!user){$('#account-panel').hidden=true;return}document.querySelectorAll('.form').forEach(x=>x.classList.remove('active'));$('#account-panel').hidden=false;$('#account-email').textContent=user.email||'Verified account';$('#account-role').textContent='Resident access · Operational features require separate staff permission.';return user}
async function submit(form,handler){const btn=form.querySelector('button[type=submit]');btn.disabled=true;try{await handler()}catch(e){note(e.message,true)}finally{btn.disabled=false}}
$('#register-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{const email=$('#register-email').value.trim().toLowerCase(),password=$('#register-password').value;if(password.length<12||!/[a-z]/.test(password)||!/[A-Z]/.test(password)||!/[0-9]/.test(password))throw Error('Use 12 or more characters, including uppercase, lowercase and a digit.');const d=await call('/signup?redirect_to='+encodeURIComponent(REDIRECT),{email,password});$('#register-password').value='';if(d.access_token){save(d);await showAccount();openNativeApp();}else note('Registration accepted. Check '+email+' for a verification email, then sign in. If no email arrives, a project admin must configure custom SMTP for public delivery.');})});
$('#login-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{const d=await call('/token?grant_type=password',{email:$('#login-email').value.trim(),password:$('#login-password').value});save(d);$('#login-password').value='';await showAccount();note('Signed in successfully as a resident.');openNativeApp();})});
$('#recover-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{const email=$('#recover-email').value.trim();await call('/recover?redirect_to='+encodeURIComponent(REDIRECT),{email});note('If this address has an account and mail delivery is configured, a reset email will be sent. Check inbox and spam.');})});
$('#new-password-form').addEventListener('submit',e=>{e.preventDefault();submit(e.currentTarget,async()=>{const t=storage.getItem(accessKey);if(!t)throw Error('Recovery token missing or expired. Request a fresh password reset email.');const password=$('#new-password').value;if(password.length<12||!/[A-Z]/.test(password)||!/[a-z]/.test(password)||!/[0-9]/.test(password))throw Error('Password needs 12+ characters, uppercase, lowercase and a digit.');await call('/user',{password},'PUT',t);$('#new-password').value='';note('Password updated. Sign in using your new password.');tab('login')})});
$('#logout').addEventListener('click',async()=>{const t=storage.getItem(accessKey);try{if(t)await call('/logout',{},'POST',t)}catch{}clear();tab('login');note('Signed out on this device.')});
async function callback(){const h=new URLSearchParams(location.hash.slice(1)),q=new URLSearchParams(location.search);const err=h.get('error_description')||q.get('error_description');if(err){note(err,true);history.replaceState(null,'',location.pathname);return}if(h.has('access_token')){save({access_token:h.get('access_token'),refresh_token:h.get('refresh_token')});const type=h.get('type');history.replaceState(null,'',location.pathname);if(type==='recovery'){tab('new-password');note('Your recovery link is verified. Set a new password.')}else{await showAccount();openNativeApp();return}return}
if(q.has('token_hash')&&q.has('type')){try{const data=await call('/verify',{token_hash:q.get('token_hash'),type:q.get('type')});save(data);history.replaceState(null,'',location.pathname);if(q.get('type')==='recovery'){tab('new-password')}else{await showAccount();openNativeApp();return}}catch(e){note(e.message,true)}return}
const signed=await showAccount();if(signed){openNativeApp();return}const pref=new URLSearchParams(location.search).get('tab');if(pref&&['login','register','recover'].includes(pref))tab(pref)
}
callback().catch(e=>note(e.message,true));
