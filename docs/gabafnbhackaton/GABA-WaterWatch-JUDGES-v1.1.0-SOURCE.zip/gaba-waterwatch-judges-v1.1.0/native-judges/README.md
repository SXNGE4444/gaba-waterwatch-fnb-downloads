# GABA WaterWatch — Judges APK 1.1.0
This is a native Android package, not a website shortcut and not an Android Studio installer.
First launch opens the resident WaterWatch home screen immediately. Anonymous judges can browse simulated area updates, submit synthetic reports to the existing public Supabase endpoint, see report history, use guides and try offline queue/sync.
Account creation and email verification are optional via the account link; protected operator/reviewer functions remain authenticated.
Fresh-install package ID: za.co.lastdices.gabawaterwatch.judges2026. This prevents a signature conflict with old demo app versions. Android 7.0+ (API24); uses only public publishable Supabase keys.
To build: bash scripts/build-judges-android.sh. Debug-signed sideload APK, not Google Play signed.
