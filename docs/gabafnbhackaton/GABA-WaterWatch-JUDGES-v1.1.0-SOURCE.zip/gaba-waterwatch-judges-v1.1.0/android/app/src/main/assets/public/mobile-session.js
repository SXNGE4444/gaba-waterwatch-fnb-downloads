'use strict';
/* Judges mode: anonymous resident access is supported. Auth is optional and no online request blocks the home screen. */
document.addEventListener('DOMContentLoaded', () => {
  const logout=document.getElementById('mobile-logout-button');
  const account=Array.from(document.querySelectorAll('a[href="auth.html"]')).find(a=>a.getAttribute('aria-label')==='Optional WaterWatch resident account');
  const token=localStorage.getItem('gaba.resident.access');
  if (!token) { if(logout)logout.hidden=true; return; }
  if(logout)logout.hidden=false;
  if(account) account.textContent='My account';
  if(!logout)return;
  logout.addEventListener('click', async () => {
    const oldToken=localStorage.getItem('gaba.resident.access');
    localStorage.removeItem('gaba.resident.access');
    localStorage.removeItem('gaba.resident.refresh');
    logout.hidden=true;
    if(account)account.textContent='Optional account';
    if(oldToken)try{
      await Promise.race([
        fetch('https://uskemdfbmuilvirqudml.supabase.co/auth/v1/logout',{method:'POST',
        headers:{apikey:'sb_publishable_iZEnOA3f0yvz6M5hnTfOvA_sMYS38Oq',Authorization:'Bearer '+oldToken}}),
        new Promise(resolve=>setTimeout(resolve,2000))
      ]);
    }catch{}
  });
});
