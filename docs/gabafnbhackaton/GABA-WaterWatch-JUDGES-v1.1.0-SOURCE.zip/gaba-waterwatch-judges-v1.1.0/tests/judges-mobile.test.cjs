const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'..');
const file=name=>fs.readFileSync(path.join(root,name),'utf8');
test('Judges APK launches self-contained resident experience without login',()=>{
  const index=file('native-judges/index.html');
  const community=file('native-judges/community.html');
  assert.match(index,/location\.replace\('community\.html'\)/);
  assert.ok(!community.includes('html.needs-auth body'));
  assert.ok(!community.includes('document.documentElement.classList.add("needs-auth")'));
  assert.match(community,/id="report-form"/);
  assert.match(community,/data-mobile-page="home"/);
  assert.match(community,/data-mobile-page="alerts"/);
  assert.match(community,/data-mobile-page="report"/);
  assert.match(community,/data-mobile-page="activity"/);
  assert.match(community,/data-mobile-page="tips"/);
});
test('Sensitive operator features are not unlocked by the public guest experience',()=>{
 const app=file('native-judges/app.js');
 const guard=file('native-judges/mobile-session.js');
 assert.match(app,/ops-locked/);
 assert.match(app,/if\(!apiConnected\)/);
 assert.ok(!guard.includes("location.replace('index.html')"));
 assert.match(guard,/if \(!token\)/);
});
test('Fresh package ID prevents legacy install signer collisions',()=>{
 const gradle=file('android/app/build.gradle');
 assert.match(gradle,/applicationId "za\.co\.lastdices\.gabawaterwatch\.judges2026"/);
 assert.match(gradle,/versionName "1\.1\.0"/);
 assert.match(file('native-judges/auth.html'),/no account needed/);
});
