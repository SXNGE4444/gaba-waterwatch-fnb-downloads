# GABA WaterWatch Judge Android v0.9.5

This folder contains the **native-only** login-first bundle for the Android phone APK, based on the working v0.9.2 application package and signing certificate.

- `index.html`: launch screen — email sign in/create/reset; no guest entry.
- `auth.js`: Supabase email registration/verification, password sign in/recovery, session storage/refresh.
- `community.html`: full Android WaterWatch Home, Updates, Report, Activity and Guides.
- `mobile-session.js`: verified-session check before displaying app; log out button.
- `app.js`: original WaterWatch report, offline queue and operator UI with native-mode identification.
- `config.js`: public client backend URL configured into native bundle at build time.

## Build

Run `bash scripts/build-judges-android.sh` in the project after installing its Node dependencies and Android SDK + JDK21. It regenerates Android assets from source and overlays this native-specific bundle. For reproducible source builds, include the Android project directory and installed Capacitor dependencies. A publishable APK still needs compatible signing; this repository contains **no private signing keys**.

Published APK package: `za.co.lastdices.gabawaterwatch.fnb`, versionCode 14, versionName 0.9.5. The signer SHA-256 is the same as working v0.9.2, which preserves upgrades for existing installations signed with that certificate. Android 7+ (API 24), target API 36. APK is a prototype/debug-signed distribution, not an independent Play Store attestation. All municipal data is synthetic.

**Evidence**: Android emulator installed build, Chrome on emulator downloaded exact entire APK, SHA256 matched published build, email login/registration forms rendered, invalid credential rejected, direct community route redirects unauthenticated user, Supabase Edge API health 200. Full real-user sign-in and physically installed user phone remain unverified.
