GABA WATERWATCH · FNB APP OF THE YEAR 2026
ANDROID RELEASE 0.9.4 · INSTALLATION AND JUDGE TESTING

This archive contains TWO valid Android APK files. Install only ONE to start.

OPTION 1: GABA-WaterWatch-FNB-v0.9.4-UPDATE.apk
  • Preferred if you already have GABA WaterWatch FNB 0.9.2/0.9.3.
  • Uses the existing package za.co.lastdices.gabawaterwatch.fnb.
  • Attempts to preserve the same app's locally stored demo reports.
  • Use Android Files/My Files to install after extracting from ZIP.

OPTION 2: GABA-WaterWatch-FNB-v0.9.4-FRESH-INSTALL.apk
  • Use if UPDATE fails because of package/signature conflicts.
  • Independent package za.co.lastdices.gabawaterwatch.fnb.fresh.
  • Does not access old app data; sync your queued reports first.
  • Both options use the same live backend; don't confuse app local Activity lists.

SYSTEM REQUIREMENTS
  Android 7.0 or newer (API 24+), normal Android APK installation allowed.
  Full universal APK with bundled JS/CSS/assets; not an AAB, not a shortcut.
  Debug/demo signing; Play Store not involved. Do NOT disable Play Protect.

PHONE STEPS
  1. Open this ZIP using Files/My Files, EXTRACT, then tap an actual .apk file.
  2. If prompted, permit installs from your trusted Files app, NOT every source.
  3. Open GABA WaterWatch FNB. It starts in resident/community mode.
  4. Tap Account → Create account / Sign in using your own verified email.
  5. Email confirmation link opens the public auth page in a browser; return to
     the installed app and sign in with the same email and chosen password.
  6. Check Home, Updates, Report, Activity, Guides.
  7. Tap Report, use a fictional description and select Khayelitsha East.
  8. Submit and check Activity → Sync: a REP-* reference means cloud received.
  9. On the Operator dashboard (LD icon), log in with the already authorised
     account kidsonxanax@gmail.com and YOUR existing password.
 10. In Community Inbox, find the new report by ID. Staff access needs email
     verification plus a specific Supabase fnb_staff_roles assignment.
 11. Reviewer simulation requires a separate approved login:
     lsmptylastsaymatters@gmail.com; register/verify via staff-setup page.
     Reviewer role is not activated at release validation. Do not claim otherwise.

WEB AND DOWNLOAD LINKS
 Resident: https://www.lastdicesptyltd.co.za/gabafnbhackaton/?view=community
 Account: https://www.lastdicesptyltd.co.za/gabafnbhackaton/auth.html
 Operator: https://www.lastdicesptyltd.co.za/gabafnbhackaton/?view=operator
 Reviewer: https://www.lastdicesptyltd.co.za/gabafnbhackaton/review.html
 Staff setup: https://www.lastdicesptyltd.co.za/gabafnbhackaton/staff-setup.html
 Help: https://www.lastdicesptyltd.co.za/gabafnbhackaton/download.html
 Source: https://github.com/SXNGE4444/GABA

VERIFIED BEFORE RELEASE (24 October 2026)
 - UPDATE app installed as versionCode 13 and v0.9.4 on Android emulator.
 - FRESH app installed independently as versionCode 13 and v0.9.4-fresh.
 - Signatures v2 and v3 verified. Both apps are universal single APKs.
 - Both native paths opened and served connected public Supabase backend.
 - Resident Account, Operator and Reviewer login pages rendered in Android.
 - Fresh app offline queue → reconnect → Supabase cloud sync passed.
   Synthetic verification ID: REP-8D843A00, Received, not routed.
 - Two Supabase auth user emails verified; one is an authorised operator.
 - Unauthenticated staff endpoints remain protected. Reviewer not yet active.

LIMITATIONS / NO MISREPRESENTATION
 - Synthetic hackathon demonstration only. No live municipal systems, real
   drinking-water monitoring, or automatic notifications to municipalities.
 - Physical installation on your specific Android phone requires your test.
 - Authenticated staff workflow and reviewer review action need actual human
   login tests; no passwords are bundled.
 - Generated debug-signed APKs can be blocked by phone/organisation security.
 - Internet is required for authentication and eventual report sync; offline
   reporting is queued locally.
 - Do not submit passwords or security tokens with this package.

IF INSTALLATION FAILS
 - Confirm your phone runs Android 7.0+ and the extracted file ends .apk.
 - Confirm you have enough storage and use the actual Files/My Files app.
 - Try FRESH-INSTALL.apk when UPDATE says App not installed.
 - Do not uninstall older GABA if reports have not yet synced.
 - On an enterprise-managed phone, sideloading may be blocked by policy.
 - Capture the exact installer error and Android version for diagnosis.
 - Web demo works without APK installation while testing.

LAST DICES (PTY) LTD · GABA WATER INTELLIGENCE
