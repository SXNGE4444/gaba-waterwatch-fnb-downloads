# GABA WaterWatch — FNB App of the Year Hackathon 2026

Company: LAST DICES (PTY) LTD
Product: GABA WaterWatch, resident-facing component of GABA Water Intelligence
Challenge: Climate Resilience and Essential Services
Sector: Water / civic technology / infrastructure intelligence
Tagline: Water in sight. Communities in mind.

## Product overview (copy to Sonke)
GABA WaterWatch is an Android application that helps communities report water-service problems and follow what happens afterward. A resident selects a demonstration area, describes a burst pipe, water interruption or quality concern, and receives a tracking ID once the report synchronises to Supabase. Reports can be queued on-device without connectivity and synced later. A restricted operator workspace supports the planned receipt-to-investigation-to-review-to-evidence-to-resolution workflow; the simulated reviewer is separate from the operator. The competition build uses synthetic status signals and fictional incidents. It is not connected to any municipality or verified water quality monitoring feed. The prototype demonstrates a pathway for better resident visibility, operational accountability and evidence-based water-service coordination.

## Evidence and access links
Android APK v0.9.2 (separate package; Android 7+): https://www.lastdicesptyltd.co.za/gabafnbhackaton/GABA-WaterWatch-FNB-v0.9.2.apk
Android installation help: https://www.lastdicesptyltd.co.za/gabafnbhackaton/download.html
Website: https://www.lastdicesptyltd.co.za/gabafnbhackaton
Resident demo: https://www.lastdicesptyltd.co.za/gabafnbhackaton/?view=community
Operator login: https://www.lastdicesptyltd.co.za/gabafnbhackaton/?view=operator
Simulated reviewer: https://www.lastdicesptyltd.co.za/gabafnbhackaton/review.html
Source: https://github.com/SXNGE4444/GABA
Staff account activation: https://www.lastdicesptyltd.co.za/gabafnbhackaton/staff-setup.html

## Judge steps
1. Install the bundled APK on Android 7.0+ OR use the web resident demo. Because Android uses a test/debug signing key, trusted-device permission for installation from the Files/Chrome app may be needed. Do not disable Play Protect.
2. Open WaterWatch. The resident experience needs no login. It opens directly in the native APK.
3. Choose Khayelitsha East (SIMULATION) and inspect area service updates. These are not official water safety or service alerts.
4. Tap Report, select a category, use a **clearly fictional** description and submit. Record the generated REP-* ID.
5. Open Activity → Sync to confirm the report is received; turn offline QA on only if demonstrating queues. The backend is Limise Watch Supabase.
6. View the 30-second video. It shows a locally simulated full resident-to-operator-to-reviewer-to-resident outcome. A cloud operator/reviewer session is NOT validated until staff accounts are registered and email-confirmed.

## Judge login state at packaging
Resident experience: NO LOGIN REQUIRED.
Operator: kidsonxanax@gmail.com — reserved, NOT REGISTERED/VERIFIED at packaging; a unique password must be created via staff activation page before login.
Simulated reviewer: lsmptylastsaymatters@gmail.com — reserved, NOT REGISTERED/VERIFIED at packaging; a different unique password must be created via staff activation page before login.
Do not submit these accounts as working passwords until authenticated cloud tests pass.

## Demonstration limitations
All monitoring data, incidents and simulated provider verification are fictional; the application does not provide official municipal alerts, actual water quality measurements or real municipal resolution evidence. Resident report submission and status tracking DO persist to Supabase. An Android emulator installation, in-app cloud submission, and offline queue recovery were tested. Physical installation on all specific phone models was NOT verified. The 30-second workflow recording was made against a LOCAL synthetic demo backend.

## Technology
Android: Capacitor packaged HTML/CSS/JavaScript application with all user interface assets bundled in the APK.
Backend: Supabase Edge Function + PostgreSQL, isolated fnb_ tables with RLS and secure staff role mapping after email confirmation.
Identity: Supabase Auth; private operator/reviewer routes require verified accounts and explicit roles.
Design: resident-first mobile flow, accessibility-minded navigation, offline queue and transparent source labels.
